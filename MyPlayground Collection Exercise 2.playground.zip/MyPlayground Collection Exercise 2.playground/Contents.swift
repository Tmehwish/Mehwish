import UIKit


var seashellcollection: [String: String] = ["SV": "Sunray Venus", "GC": "Giant Cockle", "SC": "Scotch Bonnet", "SE": "Shark Eye", "LW": "Lighting Whelk", "D": "Dosina"]
print("My Seashell Collection dictionary has \(seashellcollection.count) seashelles.")
