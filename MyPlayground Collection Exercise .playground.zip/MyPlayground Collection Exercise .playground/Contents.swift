import UIKit

// I am creating an array about seashells
var seashellList: [String] = ["Sunray Venus"]

// Adding to array
seashellList.append("Giant Cockle")
seashellList.append("Scotch Bonnet")
seashellList.append("Shark Eye")
seashellList.append("Lightning Whelk")
seashellList.append("Dosina")

//Print the final array
print("I collect seashells. I have \(seashellList) and many more")
