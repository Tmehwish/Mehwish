import UIKit



// Set one of variables and constants minutes converted to seconds
var maxTime = 180
let stop = "Your Time Is Up"
for timer in 0...maxTime{
    //Print each second on the time
    print ("\timer) in seconds")
// When the timer is up display a message
    if timer == maxTime {
print(stop)
}
}
