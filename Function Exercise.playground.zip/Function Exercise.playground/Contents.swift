import UIKit

var cats = 10
var dogs = 20

func countoftotalpets(cats: Int, dogs:Int) -> Int {
      
let totalPets = cats + dogs
   return (totalPets)
}
print ("cats + dogs = \(countoftotalpets(cats: cats, dogs: dogs))")
