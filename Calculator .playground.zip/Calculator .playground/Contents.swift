import UIKit

var greeting = "Hello, playground"

// These are my variables
var Num1 = 100
var Num2 = 10

// These are my calculations
var mult = Num1 * Num2
var div = Num1 / Num2
var sub = Num1 - Num2
var add = Num1 + Num2

// Printed out results
print("\(Num1) * \(Num2) = \(mult)")
print("\(Num1) / \(Num2) = \(div)")
print("\(Num1) - \(Num2) = \(sub)")
print("\(Num1) + \(Num2) = \(add)")
